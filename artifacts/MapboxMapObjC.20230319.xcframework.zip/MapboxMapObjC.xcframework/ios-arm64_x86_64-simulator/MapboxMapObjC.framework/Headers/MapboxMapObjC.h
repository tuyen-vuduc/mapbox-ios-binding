#import <Foundation/Foundation.h>

//! Project version number for MapboxMapObjC.
FOUNDATION_EXPORT double MapboxMapObjCVersionNumber;

//! Project version string for MapboxMapObjC.
FOUNDATION_EXPORT const unsigned char MapboxMapObjCVersionString[];
